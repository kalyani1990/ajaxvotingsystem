-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2018 at 07:35 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pp_core_voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `v_admin`
--

CREATE TABLE `v_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `v_admin`
--

INSERT INTO `v_admin` (`id`, `username`, `pwd`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `v_subjects`
--

CREATE TABLE `v_subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_title` text NOT NULL,
  `subject_opt_1` varchar(255) NOT NULL,
  `subject_opt_2` varchar(255) NOT NULL,
  `subject_opt_3` varchar(255) NOT NULL,
  `subject_opt_4` varchar(255) NOT NULL,
  `subject_opt_5` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `expiry_time` varchar(255) NOT NULL,
  `subject_add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `v_subjects`
--

INSERT INTO `v_subjects` (`subject_id`, `subject_title`, `subject_opt_1`, `subject_opt_2`, `subject_opt_3`, `subject_opt_4`, `subject_opt_5`, `start_time`, `expiry_time`, `subject_add_time`) VALUES
(4, 'Vote your favorite vegetable', 'Patato', 'Tomato', 'Onion', 'Garlic', 'Lady Finger', '1542942479', '1545247279', '2018-12-07 03:10:10'),
(5, 'Vote Your Favorite Fruit', 'Apple', 'Mango', 'Banana', 'Orange', 'Grapes', '1542943678', '1545248478', '2018-12-07 03:10:16'),
(6, 'Your Favorite Programming Language', 'Php', 'Python', 'Javascript', 'Java', 'Ruby', '1544153252', '1544758052', '2018-12-07 03:27:32');

-- --------------------------------------------------------

--
-- Table structure for table `v_users`
--

CREATE TABLE `v_users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `v_users`
--

INSERT INTO `v_users` (`user_id`, `full_name`, `email`, `pwd`, `created_at`) VALUES
(2, 'Sugam', 'sugam@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2018-12-01 03:02:47');

-- --------------------------------------------------------

--
-- Table structure for table `v_user_votes`
--

CREATE TABLE `v_user_votes` (
  `user_vote_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `opt_no` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `voting_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `v_user_votes`
--

INSERT INTO `v_user_votes` (`user_vote_id`, `subject_id`, `opt_no`, `user_id`, `voting_time`) VALUES
(1, 5, 2, 1, '2018-12-07 03:10:51'),
(2, 4, 5, 1, '2018-12-07 03:10:54'),
(3, 5, 4, 2, '2018-12-07 03:17:14'),
(4, 4, 1, 2, '2018-12-07 03:17:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `v_admin`
--
ALTER TABLE `v_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `v_subjects`
--
ALTER TABLE `v_subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `v_users`
--
ALTER TABLE `v_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `v_user_votes`
--
ALTER TABLE `v_user_votes`
  ADD PRIMARY KEY (`user_vote_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `v_admin`
--
ALTER TABLE `v_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `v_subjects`
--
ALTER TABLE `v_subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `v_users`
--
ALTER TABLE `v_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `v_user_votes`
--
ALTER TABLE `v_user_votes`
  MODIFY `user_vote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
